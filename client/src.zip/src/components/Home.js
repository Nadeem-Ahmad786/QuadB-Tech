import React, { useEffect, useState } from 'react'
import { getData } from '../api/product'

const Home = () => {
    const [data, setData] = useState("");

    useEffect(()=>{
        loadData()
    },[]);
    const loadData=()=>{
        getData()
        .then(response => {
            console.log(response.data.product)
            setData(response.data.product);
        })
    }
  return (
    <div className='min-vh-100 p-2 px-4'>
        { data && data.map(element=>{
            return (
            <div className='rounded p-2 mb-2 bg-light'>
                
            </div>
        )})}
    </div>
  )
}

export default Home