import React from 'react'

const ErrorPage = () => {
  return (
    <div>page not found, please return to home page</div>
  )
}

export default ErrorPage